//
//  W02_HowieTests.swift
//  W02_HowieTests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W02_Howie

struct W02_HowieTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
