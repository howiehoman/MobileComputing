//
//  W02_HowieApp.swift
//  W02_Howie
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W02_HowieApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
