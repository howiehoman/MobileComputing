//
//  ContentView.swift
//  W02_Howie
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var isOn: Bool = false
    @State private var volume: Double = 0.5
    @State private var name: String = ""
    @State private var point = 80
    
    private func progressCard(score: Int) -> some View {
        VStack() {
            Text ("Current Score").font(.headline)
            ProgressView(value: Double(score), total: 100)
            
            Text("\(score)/100").foregroundStyle(.secondary)
        }
        
        .foregroundColor(.black)
        .padding()
        .background(.mint)
        .cornerRadius(20)
        
    }
    
    private func actionButton(_ title: String, perform action: @escaping () -> Void) -> some View {
        Button(title, action: action)
            .padding()
            .foregroundColor(.white)
            .background(Color.mint)
            .cornerRadius(10)
    }
    
    let fruits = ["Apple", "Banana", "Orange", "Mango"]
    
    var body: some View {
        
        List(fruits, id: \.self) { fruit in
            HStack {
                Text(fruit)
                Spacer()
                Text("u u a a")
            }
        }
        
        VStack {
            progressCard(score: point)
            HStack {
                actionButton("Add 10") {
                    point += 10}
                actionButton("Reset") {
                    point = 0}
            }
        }
        
        VStack {
            Toggle("Enable Notifications", isOn: $isOn)
                .padding()
            Text(isOn ? "Hore" : "Yahh")
                .padding()
            Slider(value: $volume, in: 0...1)
            Text("Current Volume : \(volume)%")
            
            TextField("Namamu siapa bolo?", text: $name)
                .textFieldStyle(.roundedBorder)
                .padding(20)
            Text("Hello \(name)!")
        }
        
//        VStack {
//            Image(systemName: "figure.pilates")
//                .padding()
//                .symbolRenderingMode(.multicolor)
//                .foregroundColor(.mint)
//                .font(.system(size: 50))
//        }
//        
//        VStack {
//            Button("Click Me~") {
//                print("Saya Tertekan")
//            }
//            .padding(0)
//            .buttonStyle(.bordered)
//            .tint(.mint )
//            
//        }
        //Container
//        VStack(spacing: 8) {
//            Spacer()
//            Text("Howie")
//            Text("Surabaya")
//            Text("wie")
//            Spacer() //menuhin container sampai mentok or memisahkan memenuhi layar
//
//        ZStack {
//            RoundedRectangle(cornerRadius: 20)
//                .fill(.mint)
//                .frame(width: 200, height: 125)
//                .shadow(color: .cyan,
//                        radius: 50, x:2, y:2)
//                .opacity(0.88)
//            
//            HStack {
//                Text("Dave")
//                    .foregroundColor(.black)
//                    .font(.headline)
//                    .padding(.bottom,80)
//                    .padding(10)
//                    .padding(.trailing,5)
//                
//                VStack{
//                    Text("👇🏻")
//                        .padding(.top,50)
//                    Text("🫨💩")
//                }
//            }
//            .padding(30)
        
//            Circle()
//                .frame(width: 200, height: 125)
//                .opacity(0.2)
//        }
//        
//        VStack {
//                Text("Shadow Example")
//                .padding()
//                .background(Color.indigo.opacity(0.2))
//                .cornerRadius(10)
//                .shadow(color: .indigo, radius: 5)
//            
//                }
//        
        
        .padding()
//        .background(.gray.opacity(0.2))
    }
}

#Preview {
    ContentView()
}
