//
//  W02_TakeHome_ToDoListApp.swift
//  W02_TakeHome_ToDoList
//
//  Created by Howie Homan on 20/09/25.
//

import SwiftUI

@main
struct W02_TakeHome_ToDoListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
