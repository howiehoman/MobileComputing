//
//  ContentView.swift
//  W02_TakeHome_ToDoList
//
//  Created by Howie Homan on 20/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var tasks: [String] = []
    @State private var newTask: String = ""
    @State private var completedTasks: [Bool] = []
    
    var body: some View {
        VStack {
            // Title
            VStack {
                Text("The To Do List")
                    .font(.largeTitle .bold() )
                    .foregroundColor(.teal)
                Text("by Howie Homan")
                    .font(.body)
                    .foregroundColor(.secondary)
                
                HStack {
                    Image(systemName: "checklist")
                        .font(.headline)
                        .foregroundColor(.mint)
                        
                    Text("My Tasks")
                        .font(.headline)
                        .foregroundColor(.teal)
                    
                }
                .padding()
            }
            .padding(.vertical)
            
            // Add task
            HStack {
                TextField("Add new task", text: $newTask)
                    .textFieldStyle(.roundedBorder)
                
                Button("Add") {
                    if !newTask.isEmpty {
                        tasks.append(newTask)
                        completedTasks.append(false)
                        newTask = ""
                    }
                }
                .padding()
                .background(.mint)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
            
            // Task list
            ScrollView {
                LazyVStack {
                    ForEach(0..<tasks.count, id: \.self) { index in
                        HStack {
                            Button(action: {
                                completedTasks[index].toggle()
                            }) {
                                Image(systemName: completedTasks[index] ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(completedTasks[index] ? .mint : .blue)
                                    .font(.headline)
                            }
                            
                            Text(tasks[index])
                                .font(.headline)
                                .strikethrough(completedTasks[index])
                                .foregroundColor(completedTasks[index] ? .secondary : .primary)
                            
                            Spacer()
                            
                            // Delete button
                            Button(action: {
                                deleteTask(at: index)
                            }) {
                                Image(systemName: "trash.fill")
                                    .foregroundColor(.red)
                                    .font(.caption)
                            }
                        }
                        .padding()
                        .background(.mint.opacity(0.1))
                        .cornerRadius(10)
                        .padding(.horizontal)
                        .padding(.vertical, 2)
                    }
                }
            }
            
            // Add sample tasks button
            Button("+ Sample") {
                tasks.append("Isi Bensin Creta")
                completedTasks.append(false)
                tasks.append("Cuci Pajero")
                completedTasks.append(false)
                tasks.append("Ambil Macbook dari Tempat Service")
                completedTasks.append(false)
            }
            .font(.caption)
            .padding(.horizontal, 20)
            .padding(.vertical, 8)
            .background(.teal)
            .foregroundColor(.white)
            .cornerRadius(8)
            
        }
        .padding()
    }
    
    private func deleteTask(at index: Int) {
        tasks.remove(at: index)
        completedTasks.remove(at: index)
    }
}

#Preview {
    ContentView()
}
