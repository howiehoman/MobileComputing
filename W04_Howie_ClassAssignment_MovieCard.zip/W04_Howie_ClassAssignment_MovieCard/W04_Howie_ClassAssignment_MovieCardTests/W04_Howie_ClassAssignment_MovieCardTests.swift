//
//  W04_Howie_ClassAssignment_MovieCardTests.swift
//  W04_Howie_ClassAssignment_MovieCardTests
//
//  Created by Howie Homan on 02/10/25.
//

import Testing
@testable import W04_Howie_ClassAssignment_MovieCard

struct W04_Howie_ClassAssignment_MovieCardTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
