//
//  W04_Howie_ClassAssignment_MovieCardApp.swift
//  W04_Howie_ClassAssignment_MovieCard
//
//  Created by Howie Homan on 02/10/25.
//

import SwiftUI

@main
struct W04_Howie_ClassAssignment_MovieCardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
