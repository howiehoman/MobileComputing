//
//  ContentView.swift
//  W04_Howie_ClassAssignment_MovieCard
//
//  Created by Howie Homan on 02/10/25.
//

import SwiftUI

// MARK: - Movie Model
struct Movie: Identifiable {
    var id = UUID()
    let title: String
    let posterURL: String
    let genre: String
    let runtime: Int
    let year: String
    let synopsis: String
    let rating: Double
    let director: String
    let producer: String
    let writer: String
    var isWatchlisted: Bool = false
    var isWatched: Bool = false
}

// MARK: - MovieStore
class MovieStore: ObservableObject {
    @Published var movies: [Movie] = [
        Movie(
            title: "Sinners",
            posterURL: "https://m.media-amazon.com/images/M/MV5BNjIwZWY4ZDEtMmIxZS00NDA4LTg4ZGMtMzUwZTYyNzgxMzk5XkEyXkFqcGc@._V1_.jpg",
            genre: "Horror / Supernatural",
            runtime: 138,
            year: "2025",
            synopsis: "In 1932 in the Mississippi Delta, twin brothers Elijah 'Smoke' Moore and Elias 'Stack' Moore return home from Chicago after making a fortune in mob work, intending to open a juke joint in their hometown. But they discover a lurking supernatural evil in their hometown that threatens everything they sought to build.",
            rating: 7.8,
            director: "Ryan Coogler",
            producer: "Ryan Coogler, Zinzi Coogler, Sev Ohanian",
            writer: "Ryan Coogler"
        ),
        Movie(
            title: "Thunderbolts",
            posterURL: "https://m.media-amazon.com/images/M/MV5BYWE2NmNmYTItZGY0ZC00MmY2LTk1NDAtMGUyMGEzMjcxNWM0XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg",
            genre: "Superhero / Action",
            runtime: 125,
            year: "2025",
            synopsis: "Part of the Marvel Cinematic Universe, Thunderbolts brings together a team of characters that are often antiheroes or reformed villains. The film explores how they navigate their missions and conflicts.",
            rating: 7.5,
            director: "Jake Schreier",
            producer: "Kevin Feige",
            writer: "Eric Pearson, Joanna Calo"
        ),
        Movie(
            title: "The Fantastic Four: First Steps",
            posterURL: "https://m.media-amazon.com/images/M/MV5BOGM5MzA3MDAtYmEwMi00ZDNiLTg4MDgtMTZjOTc0ZGMyNTIwXkEyXkFqcGc@._V1_.jpg",
            genre: "Superhero / Action",
            runtime: 120,
            year: "2025",
            synopsis: "A reboot origin story of the Fantastic Four in the Marvel Cinematic Universe, presumably covering their first acquisition of powers, the formation of the team, and their early challenges.",
            rating: 7.3,
            director: "Matt Shakman",
            producer: "Kevin Feige",
            writer: "Josh Friedman, Eric Pearson, Jeff Kaplan, Ian Springer"
        ),
        Movie(
            title: "Demon Slayer: Infinity Castle",
            posterURL: "https://m.media-amazon.com/images/M/MV5BOGQ3YWUzYjEtMTJiYy00ZjQ0LWI0YjktYjhiNGVhNGExYTM3XkEyXkFqcGc@._V1_.jpg",
            genre: "Animation / Fantasy",
            runtime: 115,
            year: "2025",
            synopsis: "This film adapts the Infinity Castle arc from Demon Slayer. It follows the Demon Slayer Corps in a high-stakes confrontation with powerful demons inside the Infinity Castle.",
            rating: 8.6,
            director: "Haruo Sotozaki",
            producer: "Ufotable, Aniplex",
            writer: "Koyoharu Gotouge"
        ),
        Movie(
            title: "Superman",
            posterURL: "https://m.media-amazon.com/images/M/MV5BOGMwZGJiM2EtMzEwZC00YTYzLWIxNzYtMmJmZWNlZjgxZTMwXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg",
            genre: "Action / Superhero",
            runtime: 129,
            year: "2025",
            synopsis: "Clark Kent / Superman must reconcile his alien Kryptonian heritage with his human upbringing as a reporter. As the embodiment of truth, justice, and the human way, he soon faces a world that regards those ideals as outdated or naive.",
            rating: 7.2,
            director: "James Gunn",
            producer: "James Gunn, Peter Safran",
            writer: "James Gunn, Jerry Siegel, Joe Shuster"
        ),
        Movie(
            title: "Weapons",
            posterURL: "https://m.media-amazon.com/images/M/MV5BNTBhNWJjZWItYzY3NS00M2NkLThmOWYtYTlmNzBmN2UxZWFjXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg",
            genre: "Mystery / Horror",
            runtime: 128,
            year: "2025",
            synopsis: "Early one morning at 2:17 A.M. in Maybrook, Pennsylvania, 17 children from the same class simultaneously leave their homes and run off into the night. Their teacher, Justine Gandy, arrives hours later to find only one student in the classroom.",
            rating: 7.6,
            director: "Zach Cregger",
            producer: "Zach Cregger, Roy Lee, Miri Yoon, J.D. Lifshitz, Raphael Margules",
            writer: "Zach Cregger"
        )
    ]
    
    func toggleWatchlist(for movie: Movie) {
        if let index = movies.firstIndex(where: { $0.id == movie.id }) {
            movies[index].isWatchlisted.toggle()
        }
    }
    
    func toggleWatched(for movie: Movie) {
        if let index = movies.firstIndex(where: { $0.id == movie.id }) {
            movies[index].isWatched.toggle()
        }
    }
    
    var watchlistedMovies: [Movie] {
        movies.filter { $0.isWatchlisted }
    }
    
    var watchedMovies: [Movie] {
        movies.filter { $0.isWatched }
    }
}

// MARK: - ContentView
struct ContentView: View {
    @StateObject private var movieStore = MovieStore()
    
    var body: some View {
        TabView {
            NavigationStack {
                MovieGridView()
                    .environmentObject(movieStore)
            }
            .tabItem {
                Label("Movies", systemImage: "film.stack")
            }
            
            NavigationStack {
                SearchView()
                    .environmentObject(movieStore)
            }
            .tabItem {
                Label("Search", systemImage: "magnifyingglass")
            }
            
            NavigationStack {
                SettingsView()
                    .environmentObject(movieStore)
            }
            .tabItem {
                Label("Settings", systemImage: "gearshape.fill")
            }
        }
        .tint(.cyan)
        .onAppear {
            let appearance = UITabBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = UIColor(red: 0.05, green: 0.05, blue: 0.1, alpha: 1.0)
            appearance.stackedLayoutAppearance.normal.iconColor = UIColor.gray
            appearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor.gray]
            appearance.stackedLayoutAppearance.selected.iconColor = UIColor.cyan
            appearance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor: UIColor.cyan]
            UITabBar.appearance().standardAppearance = appearance
            UITabBar.appearance().scrollEdgeAppearance = appearance
        }
    }
}

// MARK: - MovieGridView
struct MovieGridView: View {
    @EnvironmentObject var movieStore: MovieStore
    @State private var showWatchlistOnly = false
    @State private var currentSlide = 0
    
    let timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    
    var filteredMovies: [Movie] {
        showWatchlistOnly ? movieStore.watchlistedMovies : movieStore.movies
    }
    
    let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]
    
    var body: some View {
        ZStack {
            Color(red: 0.05, green: 0.05, blue: 0.1)
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 20) {
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("UCFlix")
                                .font(.system(size: 36, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                            Text("By: Howie Homan")
                                .font(.system(.subheadline, design: .rounded))
                                .foregroundColor(.gray)
                        }
                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.top, 20)
                    
                    TabView(selection: $currentSlide) {
                        ForEach(Array(movieStore.movies.enumerated()), id: \.element.id) { index, movie in
                            NavigationLink(destination: MovieDetailView(movie: movie).environmentObject(movieStore)) {
                                CarouselCard(movie: movie)
                            }
                            .tag(index)
                        }
                    }
                    .tabViewStyle(.page(indexDisplayMode: .always))
                    .frame(height: 450)
                    .onReceive(timer) { _ in
                        withAnimation(.easeInOut(duration: 0.5)) {
                            currentSlide = (currentSlide + 1) % movieStore.movies.count
                        }
                    }
                    .onAppear {
                        UIPageControl.appearance().currentPageIndicatorTintColor = UIColor.cyan
                        UIPageControl.appearance().pageIndicatorTintColor = UIColor.gray.withAlphaComponent(0.3)
                    }
                    
                    HStack {
                        Toggle(isOn: $showWatchlistOnly) {
                            HStack {
                                Image(systemName: showWatchlistOnly ? "bookmark.fill" : "bookmark")
                                    .foregroundColor(.cyan)
                                Text("Watchlist Only")
                                    .font(.system(.body, design: .rounded))
                                    .foregroundColor(.white)
                            }
                        }
                        .toggleStyle(SwitchToggleStyle(tint: .cyan))
                        
                        Spacer()
                        
                        NavigationLink(destination: WatchedMoviesView().environmentObject(movieStore)) {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                Text("Watched")
                                    .font(.system(.body, design: .rounded))
                                    .foregroundColor(.white)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.white.opacity(0.1))
                            .cornerRadius(8)
                        }
                    }
                    .padding(.horizontal)
                    
                    HStack {
                        Text(showWatchlistOnly ? "My Watchlist" : "All Movies")
                            .font(.system(.title2, design: .rounded, weight: .bold))
                            .foregroundColor(.white)
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(filteredMovies) { movie in
                            NavigationLink(destination: MovieDetailView(movie: movie).environmentObject(movieStore)) {
                                MovieCard(movie: movie)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.horizontal)
                    
                    Spacer(minLength: 50)
                }
            }
        }
        .navigationBarHidden(true)
    }
}

// MARK: - StarRating
struct StarRating: View {
    let rating: Double
    let maxRating: Int = 5
    let size: CGFloat
    let color: Color
    
    var body: some View {
        HStack(spacing: 2) {
            ForEach(0..<maxRating, id: \.self) { index in
                Image(systemName: starType(for: index))
                    .font(.system(size: size))
                    .foregroundColor(color)
            }
            Text(String(format: "%.1f", rating))
                .font(.system(size: size, weight: .semibold, design: .rounded))
                .foregroundColor(color)
        }
    }
    
    private func starType(for index: Int) -> String {
        let adjustedRating = rating / 2
        let starPosition = Double(index) + 1
        if adjustedRating >= starPosition {
            return "star.fill"
        } else if adjustedRating >= starPosition - 0.5 {
            return "star.leadinghalf.filled"
        } else {
            return "star"
        }
    }
}

// MARK: - CarouselCard
struct CarouselCard: View {
    let movie: Movie
    
    var body: some View {
        ZStack(alignment: .bottom) {
            AsyncImage(url: URL(string: movie.posterURL)) { phase in
                switch phase {
                case .empty:
                    Rectangle()
                        .fill(LinearGradient(gradient: Gradient(colors: [.purple, .blue, .cyan]), startPoint: .topLeading, endPoint: .bottomTrailing))
                        .overlay(ProgressView().tint(.white))
                case .success(let image):
                    image.resizable().aspectRatio(contentMode: .fill)
                case .failure:
                    Rectangle()
                        .fill(LinearGradient(gradient: Gradient(colors: [.purple, .blue, .cyan]), startPoint: .topLeading, endPoint: .bottomTrailing))
                        .overlay(
                            VStack(spacing: 12) {
                                Image(systemName: "film.stack")
                                    .font(.system(size: 48))
                                    .foregroundColor(.white)
                                Text(movie.title)
                                    .font(.system(.title3, design: .rounded, weight: .semibold))
                                    .foregroundColor(.white)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal)
                            }
                        )
                @unknown default:
                    EmptyView()
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 450)
            .clipped()
            
            LinearGradient(gradient: Gradient(colors: [.clear, .clear, Color.black.opacity(0.3), Color.black.opacity(0.7), Color.black.opacity(0.95)]), startPoint: .top, endPoint: .bottom)
            
            VStack(alignment: .leading, spacing: 12) {
                Text(movie.title)
                    .font(.system(.title, design: .rounded, weight: .bold))
                    .foregroundColor(.white)
                    .shadow(color: .black.opacity(0.3), radius: 4, x: 0, y: 2)
                
                HStack(spacing: 12) {
                    StarRating(rating: movie.rating, size: 12, color: .yellow)
                    Text("•").foregroundColor(.gray)
                    Text(movie.genre)
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundColor(.cyan)
                }
                
                HStack(spacing: 8) {
                    HStack(spacing: 4) {
                        Image(systemName: "clock")
                            .font(.caption)
                        Text("\(movie.runtime)m")
                            .font(.system(.subheadline, design: .rounded))
                    }
                    .foregroundColor(.white.opacity(0.8))
                    Text("•").foregroundColor(.gray)
                    Text("\(movie.year)")
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundColor(.white.opacity(0.8))
                }
                
                Text(movie.synopsis)
                    .font(.system(.caption, design: .rounded))
                    .foregroundColor(.white.opacity(0.7))
                    .lineLimit(2)
                    .padding(.top, 4)
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .cornerRadius(20)
        .shadow(color: .cyan.opacity(0.3), radius: 15, x: 0, y: 8)
        .padding(.horizontal)
    }
}

// MARK: - MovieCard
struct MovieCard: View {
    let movie: Movie
    @EnvironmentObject var movieStore: MovieStore
    @State private var isPressed = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ZStack(alignment: .topTrailing) {
                AsyncImage(url: URL(string: movie.posterURL)) { phase in
                    switch phase {
                    case .empty:
                        Rectangle()
                            .fill(LinearGradient(gradient: Gradient(colors: [.purple, .blue, .cyan]), startPoint: .topLeading, endPoint: .bottomTrailing))
                            .overlay(ProgressView().tint(.white))
                    case .success(let image):
                        image.resizable().aspectRatio(contentMode: .fill)
                    case .failure:
                        Rectangle()
                            .fill(LinearGradient(gradient: Gradient(colors: [.purple, .blue, .cyan]), startPoint: .topLeading, endPoint: .bottomTrailing))
                            .overlay(
                                VStack {
                                    Image(systemName: "film")
                                        .font(.largeTitle)
                                        .foregroundColor(.white)
                                    Text(movie.title)
                                        .font(.system(.caption, design: .rounded))
                                        .foregroundColor(.white)
                                        .multilineTextAlignment(.center)
                                        .padding(.horizontal, 8)
                                }
                            )
                    @unknown default:
                        EmptyView()
                    }
                }
                .frame(height: 240)
                .clipped()
                
                if movie.isWatchlisted {
                    Image(systemName: "bookmark.fill")
                        .foregroundColor(.cyan)
                        .padding(8)
                        .background(Circle().fill(Color.black.opacity(0.7)).shadow(color: .cyan.opacity(0.5), radius: 4, x: 0, y: 2))
                        .padding(8)
                }
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text(movie.title)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .lineLimit(2)
                
                HStack(spacing: 6) {
                    StarRating(rating: movie.rating, size: 10, color: .yellow)
                }
                
                Text(movie.genre)
                    .font(.system(.caption, design: .rounded))
                    .foregroundColor(.cyan)
                    .lineLimit(1)
                
                HStack(spacing: 8) {
                    HStack(spacing: 4) {
                        Image(systemName: "clock.fill").font(.caption2)
                        Text("\(movie.runtime)m").font(.system(.caption2, design: .rounded))
                    }
                    Text("•").font(.caption2)
                    Text("\(movie.year)").font(.system(.caption2, design: .rounded))
                }
                .foregroundColor(.gray)
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(gradient: Gradient(colors: [Color(red: 0.08, green: 0.08, blue: 0.15), Color(red: 0.12, green: 0.12, blue: 0.22)]), startPoint: .top, endPoint: .bottom))
        }
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(LinearGradient(gradient: Gradient(colors: [.cyan.opacity(0.3), .purple.opacity(0.3)]), startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
        .shadow(color: .cyan.opacity(0.2), radius: 8, x: 0, y: 4)
        .scaleEffect(isPressed ? 0.95 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: isPressed)
        .onLongPressGesture(minimumDuration: 0, maximumDistance: .infinity, pressing: { pressing in
            isPressed = pressing
        }, perform: {})
    }
}

// MARK: - MovieDetailView
struct MovieDetailView: View {
    let movie: Movie
    @EnvironmentObject var movieStore: MovieStore
    
    var currentMovie: Movie {
        movieStore.movies.first(where: { $0.id == movie.id }) ?? movie
    }
    
    var body: some View {
        ZStack {
            Color(red: 0.05, green: 0.05, blue: 0.1).ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 0) {
                    ZStack(alignment: .center) {
                        AsyncImage(url: URL(string: movie.posterURL)) { phase in
                            switch phase {
                            case .empty:
                                Rectangle()
                                    .fill(LinearGradient(gradient: Gradient(colors: [.purple, .blue]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .overlay(ProgressView().tint(.white))
                            case .success(let image):
                                image.resizable().aspectRatio(contentMode: .fill)
                            case .failure:
                                Rectangle()
                                    .fill(LinearGradient(gradient: Gradient(colors: [.purple, .blue]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .overlay(Image(systemName: "film.stack").font(.system(size: 60)).foregroundColor(.white))
                            @unknown default:
                                EmptyView()
                            }
                        }
                        .frame(height: 420)
                        .clipped()
                        .overlay(
                            LinearGradient(gradient: Gradient(colors: [Color.black.opacity(0.4), .clear, .clear, Color(red: 0.05, green: 0.05, blue: 0.1).opacity(0.8), Color(red: 0.05, green: 0.05, blue: 0.1)]), startPoint: .top, endPoint: .bottom)
                        )
                        
                        Button(action: {}) {
                            Circle()
                                .fill(Color.white.opacity(0.3))
                                .frame(width: 80, height: 80)
                                .overlay(Circle().stroke(Color.white.opacity(0.5), lineWidth: 2))
                                .overlay(Image(systemName: "play.fill").font(.system(size: 28)).foregroundColor(.white).offset(x: 3))
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 20) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(movie.title.uppercased())
                                .font(.system(size: 26, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                                .multilineTextAlignment(.leading)
                            Text(movie.genre)
                                .font(.system(.body, design: .rounded))
                                .foregroundColor(.gray)
                        }
                        
                        HStack(spacing: 12) {
                            HStack(spacing: 6) {
                                Image(systemName: "clock").font(.caption)
                                Text("\(movie.runtime)m").font(.system(.subheadline, design: .rounded, weight: .medium))
                            }
                            .foregroundColor(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.white.opacity(0.1))
                            .cornerRadius(20)
                            
                            HStack(spacing: 4) {
                                Image(systemName: "r.square.fill")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(.black)
                                    .padding(4)
                                    .background(Color.yellow)
                                    .cornerRadius(4)
                                Text("R13").font(.system(.caption, design: .rounded, weight: .semibold)).foregroundColor(.white)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.white.opacity(0.1))
                            .cornerRadius(20)
                            
                            Text("2D-3D")
                                .font(.system(.subheadline, design: .rounded, weight: .medium))
                                .foregroundColor(.white)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(Color.white.opacity(0.1))
                                .cornerRadius(20)
                        }
                        
                        Divider().background(Color.white.opacity(0.2))
                        
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Synopsis")
                                .font(.system(.title3, design: .rounded, weight: .bold))
                                .foregroundColor(.white)
                            Text(movie.synopsis)
                                .font(.system(.body, design: .rounded))
                                .foregroundColor(.gray)
                                .lineSpacing(6)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        
                        Divider().background(Color.white.opacity(0.2))
                        
                        VStack(alignment: .leading, spacing: 16) {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Producer").font(.system(.subheadline, design: .rounded, weight: .semibold)).foregroundColor(.white)
                                Text(movie.producer).font(.system(.subheadline, design: .rounded)).foregroundColor(.gray)
                            }
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Director").font(.system(.subheadline, design: .rounded, weight: .semibold)).foregroundColor(.white)
                                Text(movie.director).font(.system(.subheadline, design: .rounded)).foregroundColor(.gray)
                            }
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Writers").font(.system(.subheadline, design: .rounded, weight: .semibold)).foregroundColor(.white)
                                Text(movie.writer).font(.system(.subheadline, design: .rounded)).foregroundColor(.gray)
                            }
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Release Year").font(.system(.subheadline, design: .rounded, weight: .semibold)).foregroundColor(.white)
                                Text(movie.year).font(.system(.subheadline, design: .rounded)).foregroundColor(.gray)
                            }
                            VStack(alignment: .leading, spacing: 6) {
                                Text("IMDb Rating").font(.system(.subheadline, design: .rounded, weight: .semibold)).foregroundColor(.white)
                                HStack(spacing: 8) {
                                    StarRating(rating: movie.rating, size: 14, color: .yellow)
                                }
                            }
                        }
                        
                        VStack(spacing: 12) {
                            Button(action: { movieStore.toggleWatchlist(for: movie) }) {
                                HStack {
                                    Image(systemName: currentMovie.isWatchlisted ? "bookmark.fill" : "bookmark").font(.system(size: 18))
                                    Text(currentMovie.isWatchlisted ? "Added to Watchlist" : "Add to Watchlist").font(.system(.body, design: .rounded, weight: .semibold))
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                                .background(currentMovie.isWatchlisted ? Color.cyan : Color.white.opacity(0.1))
                                .foregroundColor(currentMovie.isWatchlisted ? .black : .white)
                                .cornerRadius(12)
                            }
                            
                            Button(action: { movieStore.toggleWatched(for: movie) }) {
                                HStack {
                                    Image(systemName: currentMovie.isWatched ? "checkmark.circle.fill" : "checkmark.circle").font(.system(size: 18))
                                    Text(currentMovie.isWatched ? "Marked as Watched" : "Mark as Watched").font(.system(.body, design: .rounded, weight: .semibold))
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                                .background(currentMovie.isWatched ? Color.green : Color.white.opacity(0.1))
                                .foregroundColor(currentMovie.isWatched ? .black : .white)
                                .cornerRadius(12)
                            }
                        }
                        .padding(.top, 8)
                        
                        Spacer(minLength: 40)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, -40)
                }
            }
            .ignoresSafeArea(edges: .top)
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
    }
}

// MARK: - SearchView
struct SearchView: View {
    @EnvironmentObject var movieStore: MovieStore
    @State private var searchText = ""
    
    var filteredMovies: [Movie] {
        if searchText.isEmpty {
            return movieStore.movies
        } else {
            return movieStore.movies.filter { $0.title.localizedCaseInsensitiveContains(searchText) || $0.genre.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    let columns = [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)]
    
    var body: some View {
        ZStack {
            Color(red: 0.05, green: 0.05, blue: 0.1).ignoresSafeArea()
            
            VStack(spacing: 0) {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                        .font(.system(size: 18))
                    
                    TextField("Search movies or genres...", text: $searchText)
                        .foregroundColor(.white)
                        .font(.system(.body, design: .rounded))
                        .autocorrectionDisabled()
                }
                .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(12)
                    .padding()
                    
                    ScrollView {
                        if searchText.isEmpty {
                            VStack(spacing: 16) {
                                Image(systemName: "magnifyingglass.circle")
                                    .font(.system(size: 60))
                                    .foregroundColor(.gray)
                                
                                Text("Search for Movies")
                                    .font(.system(.title3, design: .rounded, weight: .semibold))
                                    .foregroundColor(.white)
                                
                                Text("Enter a movie title or genre")
                                    .font(.system(.caption, design: .rounded))
                                    .foregroundColor(.gray)
                            }
                            .padding(.top, 100)
                        } else if filteredMovies.isEmpty {
                            VStack(spacing: 16) {
                                Image(systemName: "film.slash")
                                    .font(.system(size: 60))
                                    .foregroundColor(.gray)
                                
                                Text("No Results")
                                    .font(.system(.title3, design: .rounded, weight: .semibold))
                                    .foregroundColor(.white)
                                
                                Text("Try searching for a different movie")
                                    .font(.system(.caption, design: .rounded))
                                    .foregroundColor(.gray)
                            }
                            .padding(.top, 100)
                        } else {
                            LazyVGrid(columns: columns, spacing: 16) {
                                ForEach(filteredMovies) { movie in
                                    NavigationLink(destination: MovieDetailView(movie: movie).environmentObject(movieStore)) {
                                        MovieCard(movie: movie)
                                    }
                                }
                            }
                            .padding(.horizontal)
                            .padding(.bottom, 50)
                        }
                    }
                }
            }
            .navigationTitle("Search")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(Color(red: 0.05, green: 0.05, blue: 0.1), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
    }

    // MARK: - SettingsView (SIMPLIFIED)
    struct SettingsView: View {
        @EnvironmentObject var movieStore: MovieStore
        
        var body: some View {
            ZStack {
                Color(red: 0.05, green: 0.05, blue: 0.1)
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        VStack(spacing: 16) {
                            Circle()
                                .fill(LinearGradient(gradient: Gradient(colors: [.cyan, .blue, .purple]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                .frame(width: 80, height: 80)
                                .overlay(Image(systemName: "person.fill").font(.system(size: 36)).foregroundColor(.white))
                            
                            Text("Howie Homan")
                                .font(.system(.title2, design: .rounded, weight: .bold))
                                .foregroundColor(.white)
                            
                            Text("howie@ciputra.ac.id")
                                .font(.system(.subheadline, design: .rounded))
                                .foregroundColor(.gray)
                        }
                        .padding(.top, 20)
                        
                        HStack(spacing: 20) {
                            VStack(spacing: 6) {
                                Text("\(movieStore.movies.count)")
                                    .font(.system(.title, design: .rounded, weight: .bold))
                                    .foregroundColor(.cyan)
                                Text("Total Movies")
                                    .font(.system(.caption, design: .rounded))
                                    .foregroundColor(.gray)
                            }
                            .frame(maxWidth: .infinity)
                            
                            VStack(spacing: 6) {
                                Text("\(movieStore.watchlistedMovies.count)")
                                    .font(.system(.title, design: .rounded, weight: .bold))
                                    .foregroundColor(.orange)
                                Text("Watchlist")
                                    .font(.system(.caption, design: .rounded))
                                    .foregroundColor(.gray)
                            }
                            .frame(maxWidth: .infinity)
                            
                            VStack(spacing: 6) {
                                Text("\(movieStore.watchedMovies.count)")
                                    .font(.system(.title, design: .rounded, weight: .bold))
                                    .foregroundColor(.green)
                                Text("Watched")
                                    .font(.system(.caption, design: .rounded))
                                    .foregroundColor(.gray)
                            }
                            .frame(maxWidth: .infinity)
                        }
                        .padding()
                        .background(Color.white.opacity(0.05))
                        .cornerRadius(16)
                        .padding(.horizontal)
                        
                        Button(action: {}) {
                            HStack {
                                Image(systemName: "rectangle.portrait.and.arrow.right")
                                    .font(.system(size: 18))
                                Text("Log Out")
                                    .font(.system(.body, design: .rounded, weight: .semibold))
                            }
                            .foregroundColor(.red)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(12)
                        }
                        .padding(.horizontal)
                        .padding(.top, 8)
                        
                        Text("UCFlix v1.0.0")
                            .font(.system(.caption, design: .rounded))
                            .foregroundColor(.gray)
                            .frame(maxWidth: .infinity)
                            .padding(.top, 8)
                            .padding(.bottom, 50)
                    }
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(Color(red: 0.05, green: 0.05, blue: 0.1), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
    }

    // MARK: - WatchedMoviesView
    struct WatchedMoviesView: View {
        @EnvironmentObject var movieStore: MovieStore
        
        let columns = [
            GridItem(.flexible(), spacing: 16),
            GridItem(.flexible(), spacing: 16)
        ]
        
        var body: some View {
            ZStack {
                Color(red: 0.05, green: 0.05, blue: 0.1)
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        if movieStore.watchedMovies.isEmpty {
                            VStack(spacing: 16) {
                                Image(systemName: "checkmark.circle")
                                    .font(.system(size: 60))
                                    .foregroundColor(.gray)
                                
                                Text("No watched movies yet")
                                    .font(.title3)
                                    .foregroundColor(.gray)
                                
                                Text("Movies you mark as watched will appear here")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                    .multilineTextAlignment(.center)
                            }
                            .padding()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .padding(.top, 100)
                        } else {
                            LazyVGrid(columns: columns, spacing: 16) {
                                ForEach(movieStore.watchedMovies) { movie in
                                    NavigationLink(destination: MovieDetailView(movie: movie).environmentObject(movieStore)) {
                                        MovieCard(movie: movie)
                                    }
                                }
                            }
                            .padding(.horizontal)
                            .padding(.top, 20)
                        }
                    }
                }
            }
            .navigationTitle("Watched Movies")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(Color(red: 0.05, green: 0.05, blue: 0.1), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
    }

    #Preview {
        ContentView()
    }
