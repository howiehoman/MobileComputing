//
//  W06_HowieApp.swift
//  W06_Howie
//
//  Created by student on 16/10/25.
//

import SwiftUI
import CoreData

@main
struct W06_HowieApp: App {
    let persistence = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            let vm = CoreDataStudentViewModel(context: persistence.container.viewContext)
            CoreDataStudentView(vm: vm)
        }
    }
}
