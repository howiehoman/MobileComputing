//
//  ContentView.swift
//  W06_Howie
//
//  Created by student on 16/10/25.
//

//Data Structure

import SwiftUI

struct ContentView: View {
//    @State private var fruits: [String] = ["Apple", "Pear", "Durian"]
    // Dictionary
    @State private var scores: [String: Int] = [
        "Alice": 90,
        "Martini": 80,
        "Sutris": 20,
    ]
    
    @State private var newName: String = ""
    @State private var newScore: String = "" // Simpan sebagai String dulu, nanti di-convert ke Int
    
    // Class
    @Observable
    class Counter {
        var count: Int = 0
        func increment() {count += 1}
        func decrement() {count -= 1}
    }
    
    @State private var counterA = Counter()
    @State private var counterC = Counter()
//    @State private var counterB = Counter()
    @State private var counterB: Counter? = nil

    // Set (gabisa duplicate sama access by index, jadi random pas input)
    @State private var programmingLanguage: Set<String> =
    ["Swift", "Python", "JavaScript"]
    @State private var newLang: String = ""
    
    // Tuple (sama kyk array, digunakan untuk data kecil, temporary data, lebih ringan drpd dictionary, )
    @State private var point: (x: Int, y: Int) = (x:0, y:0)
    
    // Enum 1
    enum Grade: String, CaseIterable {
        case A, B, C, D, E
        
        var color: Color {
            switch self {
            case .A: return .green
            case .B: return .yellow
            case .C: return .orange
            case .D: return .red
            case .E: return .blue
                
            }
        }
    }
    
    @State private var grade: Grade = .A
    
    // Enum 2
    enum APIResponse {
        case success(message: String)
        case failure(errorCode: Int, reason: String)
    }
    
    let response1 = APIResponse.success(message: "Data Loaded!")
    
    enum LoadingState {
        case idle
        case loading
        case success(data: String)
        case error(message: String)
    }
    
    @State private var state: LoadingState = .idle
    
    // Data Model (New, File from template, search Data Model, (simpan data di file ini permanent, semua yang diatas itu temporary)
    
    var body: some View {
        
        
        
        // Enum 2
//        VStack {
//            Group {
//                switch state {
//                case .idle:
//                    Text("Tap to start loading")
//                case .loading:
//                    Text("Loading..")
//                case .success(let data):
//                    Text("Loaded: \(data)")
//                        .foregroundColor(.green)
//                case .error(message: let msg):
//                    Text("Error: \(msg)")
//                        .foregroundColor(.red)
//                }
//            }
//            HStack{
//                Button("Start") {state = .loading}
//                Button("Success") {state = .success(data: "KTP mu telag di upload untuk pinjol!")}
//            }
//        }
        
        // Enum 1
//        VStack {
//            Picker("Select Grade", selection: $grade) {
//                ForEach(Grade.allCases, id: \.self) {
//                    g in Text(g.rawValue)
//                }
//            }
//            .pickerStyle(.segmented)
//            
//            Text("Your Grade: \(grade.rawValue)")
//                .font(.largeTitle.bold())
//                .foregroundColor(grade.color)
//        }
        
        
        
        // Tuple
//        VStack {
//            Text("Ini adalah Tuple")
//                .font(.largeTitle)
//            
//            Text("Nilai sekarang XY: \(point.x), \(point.y)")
//            
//            HStack {
//                Button("Kanan 10 langkah") {
//                    point.x += 10
//                }
//                .buttonStyle(.borderedProminent)
//                
//                Button("Kebawah 10 langkah") {
//                    point.y -= 10
//                }
//                .buttonStyle(.borderedProminent)
//            }
//        }
        
        
        
        // Set
//        VStack {
//            Text("Ini adalah Set")
//                .font(.largeTitle)
//            HStack {
//                ForEach(Array(programmingLanguage), id: \.self)
//                {lang in Text(lang)
//                        .padding(5)
//                        .background(.green)
//                        .clipShape(Capsule())
//                }
//            }
//            
//            HStack {
//                TextField("Enter new Language", text: $newLang)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .frame(width:200)
//                
//                Button("Add") {
//                    if !newLang.isEmpty {
//                        programmingLanguage.insert(newLang)
//                        newLang = ""
//                    }
//                }
//                .buttonStyle(.borderedProminent)
//            }
//        }
        
        // Class
//        VStack {
//            Text("Counter A : \(counterA.count)")
////            Text("Counter B : \(counterB.count)")
//            Text("Counter B : \(counterB?.count ?? 5)")
//                .foregroundStyle(counterB == nil ? .red : .primary)
//            
//            HStack {
//                Button("+") {counterA.increment()}
//                Button("-") {counterA.decrement()}
//                
//                Button(counterB == nil ? "Clone A to B" : "Unlink B") {
//                    if counterB == nil {
//                        counterB = counterA
//                    } else {
//                        counterB = nil
//                    }
//                }.buttonStyle(BorderedButtonStyle())
//                
//                Button("+") {counterB?.increment()}
//            }
//            
////            HStack {
////                Button("+") {counterB.increment()}
////                Button("-") {counterB.decrement()}
////            }
//        }
        
        
        // Dictionary
//        Scores:
//        VStack {
//            Text("Dictionary Explanation")
//                .font(Font.largeTitle)
//            VStack {
//                ForEach(scores.sorted(by: {$0.key < $1.key}), id: \.key) {
//                    name, score in
//                    HStack {
//                        Text(name)
//                        Spacer()
//                        Text("\(score)")
//                            .bold(true)
//                    }
//                }
//            }
//            .padding(10)
//            
//            HStack {
//                Button("Increase Butris' Score!") {
//                    scores["Butris", default: 0] += 5
//                }
//                .buttonStyle(.borderedProminent)
//                
//                Button("Clear All Scores") {
//                    scores.removeAll()
//                }
//                .buttonStyle(.borderedProminent)
//            }
//            .padding(20)
//
//            VStack(alignment: .leading, spacing: 10) {
//                    TextField("Enter student name", text: $newName)
//                        .textFieldStyle(RoundedBorderTextFieldStyle())
//
//                    TextField("Enter score", text: $newScore)
//                        .keyboardType(.numberPad)
//                        .textFieldStyle(RoundedBorderTextFieldStyle())
//                
//                    Button("Add Student") {
//                        if let score = Int(newScore), !newName.isEmpty {
//                            scores[newName] = score
//                            newName = ""
//                            newScore = ""
//                        }
//                    }
//            
//                    .padding(.top, 5)
//                        }
//            
//                // Buat button buat nambah nama student sesuai input textfield
//                // Buat button untuk delete semua value di Dictionary nya
//            }
//            .padding()
        
        
//        VStack {
//            Text("Array of Fruits")
//                .font(Font.largeTitle)
//            
//            HStack {
//                ForEach(fruits, id: \.self) { fruit in Text(fruit)
//                        .padding(10)
//                        .background(Color.orange.opacity(0.3))
//                        .clipShape(Capsule())
//                }
//            }
//            
//            HStack {
//                Button("Add Fruit") {
//                    fruits.append("Banana")
//                }
//                .buttonStyle(.borderedProminent)
//                
//                Button("Remove Last") {
//                    if !fruits.isEmpty {
//                        fruits.removeLast()
//                    }
//                }
//            }
//        }
        
    }
}

#Preview {
    ContentView()
}
