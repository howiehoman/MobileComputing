//
//  Task.swift
//  W05_Howie
//
//  Created by student on 09/10/25.
//

// Model <<< Fix
// ViewModel << bergerak
// View << bergerak
// Model harus matang diawal baru ngmgin function dan View" nya

import Foundation

struct Task: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var isCompleted: Bool = false
}
