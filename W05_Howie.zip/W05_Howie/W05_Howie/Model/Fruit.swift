//
//  Fruit.swift
//  W05_Howie
//
//  Created by student on 09/10/25.
//
// Ini adalah model (Swift.file)

import Foundation

struct Fruit: Identifiable, Codable, Hashable {
    let UUID: UUID // Universal Unique ID
    let id: String // A001
    let name: String // Apple
    let color: String // Green
    
    // Identifiable = Who's who
    // Codable = Struct ini bisa komunikasi dengan file lain / API
    // Hashable = Swift bisa melakukan komparasi / track codenya.
    
//    ForEach (fruits, id: \.color) (fruit) in {
//        
//    }
    
}
