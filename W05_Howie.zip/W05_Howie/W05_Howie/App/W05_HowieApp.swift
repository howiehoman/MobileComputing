//
//  W05_HowieApp.swift
//  W05_Howie
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct W05_HowieApp: App {
    var body: some Scene {
        WindowGroup {
            TaskListView()
        }
    }
}
