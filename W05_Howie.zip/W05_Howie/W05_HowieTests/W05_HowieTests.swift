//
//  W05_HowieTests.swift
//  W05_HowieTests
//
//  Created by student on 09/10/25.
//

import Testing
@testable import W05_Howie

struct W05_HowieTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
