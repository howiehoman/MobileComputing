//
//  W03_TakeHome_ApplicationUITests.swift
//  W03_TakeHome_ApplicationUITests
//
//  Created by Howie Homan on 26/09/25.
//

import Testing
@testable import W03_TakeHome_ApplicationUI

struct W03_TakeHome_ApplicationUITests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
