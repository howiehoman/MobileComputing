//
//  ContentView.swift
//  W03_TakeHome_ApplicationUI
//
//  Created by Howie Homan on 26/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            StatsView()
                .tabItem {
                    Label("Stats", systemImage: "chart.bar.fill")
                }
            WorkoutView()
                .tabItem {
                    Label("Workout", systemImage: "figure.run")
                }
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gearshape.fill")
                }
        }
        .tint(.mint)
    }
}

struct HomeView: View {
    @State private var searchText = ""
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Header Section
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Good Morning,")
                                .font(.title2)
                                .foregroundColor(.secondary)
                            Text("Howie Homan")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                        }
                        Spacer()
                        
                        // Profile Picture
                        Circle()
                            .fill(LinearGradient(
                                gradient: Gradient(colors: [.mint, .teal]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ))
                            .frame(width: 50, height: 50)
                            .overlay(
                                Image(systemName: "person.fill")
                                    .foregroundColor(.white)
                                    .font(.title2)
                            )
                    }
                    .padding(.horizontal)
                    
                    // Search Bar
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.secondary)
                        TextField("Search", text: $searchText)
                    }
                    .padding()
                    .background(.gray.opacity(0.1))
                    .cornerRadius(12)
                    .padding(.horizontal)
                    
                    // Today's Goal Section
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Text("Today's Goal")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            Spacer()
                        }
                        
                        HStack(spacing: 15) {
                            // Running Goal
                            VStack(spacing: 8) {
                                Image(systemName: "figure.run")
                                    .font(.largeTitle)
                                    .foregroundColor(.white)
                                
                                Text("4 Km")
                                    .font(.title3)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.white)
                                
                                Text("@Universitas Ciputra")
                                    .font(.caption)
                                    .foregroundColor(.white.opacity(0.8))
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(.white.opacity(0.15))
                            .cornerRadius(15)
                            
                            // Cycling Goal
                            VStack(spacing: 8) {
                                Image(systemName: "bicycle")
                                    .font(.largeTitle)
                                    .foregroundColor(.white)
                                
                                Text("2 Km")
                                    .font(.title3)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.white)
                                
                                Text("@Pakuwon City")
                                    .font(.caption)
                                    .foregroundColor(.white.opacity(0.8))
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(.white.opacity(0.15))
                            .cornerRadius(15)
                        }
                    }
                    .padding()
                    .background(
                        LinearGradient(
                            gradient: Gradient(colors: [.mint, .teal, .blue]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .cornerRadius(20)
                    .padding(.horizontal)
                    
                    // Stats Grid
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 15), count: 2), spacing: 15) {
                        // Heart Rate
                        VStack(spacing: 8) {
                            Image(systemName: "heart.fill")
                                .font(.title2)
                                .foregroundColor(.red)
                            
                            Text("72 Bpm")
                                .font(.title3)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(.gray.opacity(0.05))
                        .cornerRadius(15)
                        
                        // Calories
                        VStack(spacing: 8) {
                            Image(systemName: "flame.fill")
                                .font(.title2)
                                .foregroundColor(.orange)
                            
                            Text("245 Kcal")
                                .font(.title3)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(.gray.opacity(0.05))
                        .cornerRadius(15)
                        
                        // Weight
                        VStack(spacing: 8) {
                            Image(systemName: "scalemass.fill")
                                .font(.title2)
                                .foregroundColor(.green)
                            
                            Text("68 Kg")
                                .font(.title3)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(.gray.opacity(0.05))
                        .cornerRadius(15)
                        
                        // Sleep
                        VStack(spacing: 8) {
                            Image(systemName: "moon.fill")
                                .font(.title2)
                                .foregroundColor(.purple)
                            
                            Text("7.5 Hr")
                                .font(.title3)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(.gray.opacity(0.05))
                        .cornerRadius(15)
                    }
                    .padding(.horizontal)
                    
                    Spacer(minLength: 100)
                }
            }
            .navigationBarHidden(true)
        }
    }
}

struct StatsView: View {
    var body: some View {
        VStack {
            Text("📊 Statistics")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Text("Your stats will appear here")
                .foregroundColor(.secondary)
        }
    }
}

struct WorkoutView: View {
    var body: some View {
        VStack {
            Text("💪 Workouts")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Text("Your workouts will appear here")
                .foregroundColor(.secondary)
        }
    }
}

struct SettingsView: View {
    var body: some View {
        VStack {
            Text("⚙️ Settings")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Text("App settings will appear here")
                .foregroundColor(.secondary)
        }
    }
}

#Preview {
    ContentView()
}

