//
//  W03_TakeHome_ApplicationUIApp.swift
//  W03_TakeHome_ApplicationUI
//
//  Created by Howie Homan on 26/09/25.
//

import SwiftUI

@main
struct W03_TakeHome_ApplicationUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
