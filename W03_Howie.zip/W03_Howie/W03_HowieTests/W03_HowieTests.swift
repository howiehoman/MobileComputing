//
//  W03_HowieTests.swift
//  W03_HowieTests
//
//  Created by student on 25/09/25.
//

import Testing
@testable import W03_Howie

struct W03_HowieTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
