//
//  W03_HowieApp.swift
//  W03_Howie
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct W03_HowieApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
