//
//  ContentView.swift
//  W03_Howie
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ContentView2: View {
    
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView: View {
    //Struct itu immutable, makanya punya anak yaitu @State
    
    @State private var count = 0
    @State private var nama = ""
    @State private var totalCount = 0
    // @State adalah property wrapper, jika tidak pakai State, var nya jadi immutable atau tidak mau rubah on the fly, anggepannya jadi fixed, value nya ngga bisa diassign ke dia sendiri, parent nya adalah Struct
    
    var body: some View {
        //        VStack {
        //            ContentView2()
        //            Text("Hitung: \(count)")
        //                .font(.largeTitle)
        //            Text("Nama: \(nama)")
        //
        //            TextField("Isi Nama", text: $nama)
        //                .textFieldStyle(RoundedBorderTextFieldStyle())
        //
        //            HStack {
        //                Button("-") {
        //                    count -= 1
        //                }
        //                .font(Font.largeTitle.bold())
        //                Button("+") {
        //                    count += 1
        //                }
        //                .font(Font.largeTitle.bold())
        //            }
        //        }
        //        VStack {
        //            Text ("Parent View")
        //                .font(.largeTitle)
        //            Text("Total Count: \(totalCount)")
        //                .font(.title2)
        //                .padding()
        //            CounterView(count: $totalCount)
        //            Spacer()
        //        }
        //        TabView {
        //            HomeView()
        //                .tabItem {
        //                    Label("Home", systemImage: "house.fill")
        //                }
        //                .badge("8")
        //            SearchView()
        //                .tabItem {
        //                    Label("Search", systemImage: "magnifyingglass")
        //                }
        //            SettingView()
        //                .tabItem {
        //                    Label("Setting", systemImage: "gearshape.fill")
        //                }
        //            ProfileView()
        //                .tabItem {
        //                    Label("Profile", systemImage: "person.circle")
        //                }
        //            //                .padding()
        //            //        .background(.mint.opacity(0.5))
        //        }
        //        .tint(.mint)
        //    }
        //
        //
        //    struct HomeView: View {
        //        @State private var textKu = ""
        //        var body: some View {
        //            Form {
        //                VStack {
        //                    Text("🏠 Home")
        //                        .font(Font.largeTitle)
        //                    TextField("Name", text: $textKu)
        //                        .border(Color.gray)
        //                }
        //            }
        //            .padding()
        //            .background(.mint.opacity(0.4))
        //        }
        //    }
        //
        //
        //    struct SearchView: View {
        //        var body: some View {
        //            Text("👀 Search")
        //                .font(Font.largeTitle)
        //        }
        //    }
        //
        //    struct SettingView: View {
        //        var body: some View {
        //            Text("⚙️ Setting")
        //                .font(Font.largeTitle)
        //        }
        //    }
        //
        //    struct ProfileView: View {
        //        var body: some View {
        //            Text("👤 Profile")
        //                .font(Font.largeTitle)
        //        }
        //    }
        NavigationStack {
            VStack {
                Text ("Home Screen")
                    .font(.largeTitle)
                NavigationLink("Go to Details") {
                    DetailScreen()
                }
                NavigationLink("Show Item") {
                    ItemScreen()
                }
                
            }
        }
    }
}
struct DetailScreen: View {
    var body: some View {
        VStack {
            Text("Detail Screen")
                .font(.largeTitle)
            Text("You come from home screen!")
        }
        .navigationTitle("Detail")
        .navigationBarTitleDisplayMode(.inline)
    }
}


struct ItemScreen: View {
    let items = ["Tomato", "Papaya", "Pineapple"]
    
    var body: some View {
        List(items, id: \.self) {
            item in NavigationLink(destination: ItemDetailScreen(item:item)) {
                Text(item)
            }
        }
        .navigationTitle("Items")
    }
}

struct ItemDetailScreen: View {
    let item: String
    
    var body: some View {
        VStack {
            Text("Welcome to Item Detail!")
                .font(.title)
            Text("You Selected: \(item)")
        }
        .navigationTitle(item)
        .navigationBarTitleDisplayMode(.inline)
    }
}
    
    #Preview {
        ContentView()
    }
    
