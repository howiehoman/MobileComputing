//
//  W01_HowieApp.swift
//  W01_Howie
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_HowieApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
